import random
import numpy as np
import logging
import os
import json
import pandas as pd
import matplotlib.pyplot as plt
import math

class RegressionTechniques(Exception):
    def __init__(self,x_train,x_test,y_train,y_test,data):
        self.x_train = x_train
        self.x_test = x_test
        self.y_train = y_train
        self.y_test = y_test
        self.data = data
        self.x_train_transpose = x_train.transpose()

        self.logger = logging.getLogger(__name__)
        path = ('log_config.json')
        if os.path.exists(path):
            with open(path, 'rt') as f:
                config = json.load(f)
            logging.config.dictConfig(config)

        else:
            logging.config.dictConfig({
                'version': 1,
                'disable_existing_loggers': False,  # this fixes the problem
                'formatters': {
                    'standard': {
                        'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
                    },
                },
                'handlers': {
                    'default': {
                        'level': 'INFO',
                        'class': 'logging.StreamHandler',
                    },
                },
                'loggers': {
                    '': {
                        'handlers': ['default'],
                        'level': 'INFO',
                        'propagate': True
                    }
                }
            })


    def calculate_Hessian(self):
        return (np.multiply (self.x_train_transpose.dot (self.x_train), 4))

    def calcaulate_gradient(self,init_w_hat):

        xTx = np.dot (self.x_train_transpose, self.x_train)
        GRADIENT_VALUE = (-2 * np.dot (self.x_train.T, self.y_train)) + (2 * np.dot (xTx, init_w_hat))

        return GRADIENT_VALUE

    def calculate_ridge_estimate(self,x_train_data,y_train_data,lambda_penalty):

        size = np.shape (x_train_data)
        identity = np.identity(size[1])

        temp_xTXinv_ridge = (np.linalg.inv(x_train_data.T.dot(x_train_data) + lambda_penalty * identity))
        self.w_hat = (temp_xTXinv_ridge.dot(x_train_data.T)).dot(y_train_data)
        return self.w_hat





    def calculate_MSE(self,mean_axis=0):

        """#%%------MSE
        #w -weight of parameter to be estimated
        #X -input features for the different parameters that affect the Target
        #Y - Actual measured output
        #Yhat - Estimated value of output/target"""
        #Mean axis value decides how we calculate the error for the estimate
        #If means_axis = 0, mean is taken by adding the values along the rows and then dividing-result matches the no.of.cols of data
        #If means_axis = 1, mean is taken by adding the values along the columns and then dividing -result matched no.of rows of data
        #If means_axis = None, mean is taken elementwise - returns a single value

        """"# w= [X^t*X]^-1*X^t*y but [X^t*X]^-1*X^t -> pseudo-inverse of the rectangular matrix X
        Therefore w=(pseudo-inverse of the rectangular matrix X)y"""

        try:
            #----NORMALIZE DATA
            #-Train data
            """Calculate coeficients for different features"""
            self.logger.debug("Calculate coeficients for different features...")
            self.w=np.dot((np.linalg.pinv(self.x_train)),self.y_train)
            """ Get the estimated value based on the co-efficients and features"""
            self.logger.debug("Getting MSE Estimate...")
            self.yhat_train = self.x_train.dot(self.w)
            """Calculate the mean squared error"""
            self.logger.debug("Getting MSE Error...")
            self.error_train_MSE = np.linalg.norm(self.yhat_train-self.y_train)**2


            """Test data - apply the co-eff obtained from training to validate it against the test data"""
            self.logger.debug("Apply co-eff from traing to test data...")
            self.yhat_test = self.x_test.dot(self.w)
            self.error_test_mse= np.linalg.norm(self.yhat_test-self.y_test)**2
            self.error_train_diff = self.y_train - self.yhat_train
            self.error_test_diff = self.y_test - self.yhat_test
            self.logger.info("MSE-Final error value:"+str(self.error_test_mse))
        except (ArithmeticError, OverflowError, FloatingPointError, ZeroDivisionError) as mathError:
            self.logger.error('Math error - Failed to prepare the csv data', exc_info=True)
            raise
        except Exception as e:
            self.logger.error('Failed to calculate MSE', exc_info=True)
            raise

        """Comments---> We found the coefficients (w) once with the train data, and then find y_hat for both train and
                    test data with those coefficients. The estimated values doesn't follow the same behavior as the
                    original data because the choose of the UPDR values is not the same per each doctor, this values
                    are implicit so it's easy to have high variance and this size in the error btw the data."""

        return self.yhat_train,self.error_train_diff,self.yhat_test,self.error_test_diff,self.error_train_MSE,self.error_test_mse,self.w
# %%------SOLUTION 2 ___Gradient algorithm
    def gradientDescent(self,stopping_condn,loop_limit,gamma):
        
        # mu=0, sigma= 0.1, size= 17 - 17 FEATURES. Random gaussian values
        random.seed(40)
        init_w_hat = np.random.normal(0, 1, 17)

        self.w_hat = np.array(init_w_hat)


        i = 0
        self.error_train_diff = np.zeros(1)
        self.error_test_diff = np.zeros (1)
        self.error_train = np.zeros(1)
        self.error_test = np.zeros (1)
        self.w_vector = np.zeros(1)
        self.cost_function_gradient_vector = np.zeros(1)


        # re( ^w(i)) = -2XTy + 2XTX^w(i)

        # I have a stopping condition for the error value diff,
        # but to avoid infinite looping, i put an upper limit
        self.logger.debug("Start loop for gradient descent with stopping condn...")
        try:
            for i in range(loop_limit):
#                print("i:",i)
                # Evaluate the gradient

                prev_w_hat = self.w_hat
                """Gradient is the partial differentiation over w of th error term E[W]"""
                xTx = np.dot (self.x_train_transpose, self.x_train)
                self.gradient  = (-2 * np.dot (self.x_train.T, self.y_train)) + (2 * np.dot (xTx, prev_w_hat))

#                self.gradient = self.calcaulate_gradient(prev_w_hat)

                self.w_hat = (prev_w_hat - np.multiply(gamma, self.gradient))

                self.yhat_train = self.x_train.dot (self.w_hat)
                self.yhat_test = self.x_test.dot (self.w_hat)

                """Calculating the error for the parameter values at iteration  """

                self.current_error_test= np.linalg.norm(self.yhat_test - self.y_test)**2
                self.current_error_train = np.linalg.norm(self.yhat_train - self.y_train)**2

                self.current_error_test_diff = (self.y_test - self.yhat_test)
                self.current_error_train_diff = (self.y_train - self.yhat_train)
                if (i == 0):
                    np.put(self.error_train_diff, i, self.current_error_train_diff)
                    np.put (self.error_test_diff, i, self.current_error_test_diff)
                    np.put(self.error_train, i, self.current_error_train)
                    np.put (self.error_test, i, self.current_error_test)
                    np.put(self.w_vector,i,np.linalg.norm(self.w_hat-prev_w_hat))
                    np.put(self.cost_function_gradient_vector,i,self.gradient[0])


                elif (i > 0):
                    self.error_train_diff = np.append(self.error_train_diff, self.current_error_train_diff)
                    self.error_test_diff = np.append (self.error_test_diff, self.current_error_test_diff)
                    self.error_train = np.append(self.error_train, self.current_error_train)
                    self.error_test = np.append (self.error_test, self.current_error_test)
                    self.w_vector = np.append (self.w_vector, np.linalg.norm(self.w_hat-prev_w_hat))
                    self.cost_function_gradient_vector = np.append (self.cost_function_gradient_vector, self.gradient[0])

#                    print("EXIT VALUE- Stopping condn:",stopping_condn)
#                    print("stopping_condn value:",self.w_vector[i])
                    if (self.w_vector[i]) <= stopping_condn or (i >= loop_limit-1):
                        self.logger.info("GD- Final Change in MSError:"+str((self.error_test_diff[i-1] - self.current_error_test_diff)))
                        self.logger.info ("GD- Final Change in W:" + str ((self.w_vector[i-1] - self.w_vector[i])))
                        self.logger.info("Gradient Descent - No.of iterations required to reach stopping condn:"+str(i))
                        self.logger.info("Gradient Descent - Value of error at stopping condn:" + str(self.current_error_test))
                        self.yhat_test = self.x_test.dot (self.w_hat)
                        self.yhat_train = self.x_train.dot (self.w_hat)

                        break
        except (SystemExit, KeyboardInterrupt):
            raise
        except (ArithmeticError, OverflowError,FloatingPointError,ZeroDivisionError) as mathError:
            self.logger.error('Math error - Failed to prepare the csv data', exc_info=True)
            raise

        except Exception as e:
            self.logger.error('Failed to calculate gradient descent', exc_info=True)
            raise

        return self.w_hat,self.yhat_train,self.error_train_diff,self.yhat_test,self.error_test_diff,self.y_train,self.y_test,self.current_error_train,self.current_error_test
# %%SOLUTION 3 ___Steepest descnet algorithm a.k.a Newton's method using Hessian matrix

    def steepestDescent_Hessian(self,stopping_condn,loop_limit):
        
        # mu=0, sigma= 0.1, size= 17 - 17 FEATURES. Random gaussian values

        random.seed(40)
        init_w_hat = np.random.normal(0, 1, 17)

        self.w_hat = np.array(init_w_hat)

        self.hessian_matrix = self.calculate_Hessian()

        i = 0
        self.error_train = np.zeros(1)
        self.error_test = np.zeros (1)
        self.error_train_diff = np.zeros(1)
        self.error_test_diff = np.zeros (1)
        self.w_vector = np.zeros (1)
        self.cost_function_gradient_vector = np.zeros(1)

        # re( ^w(i)) = -2XTy + 2XTX^w(i)

        # I have a stopping condition for the error value diff,
        # but to avoid infinite looping, i put an upper limit
        self.logger.debug("Start loop for Steepest descent/Newton method with stopping condn...")
        try:
            for i in range(loop_limit):
                # Evaluate the gradient

                prev_w_hat = self.w_hat

                """Gradient is the partial differentiation over w of th error term E[W]"""
                self.gradient = self.calcaulate_gradient(prev_w_hat)

                self.gradient_transpose = self.gradient.transpose()

                self.gradient_norm_squared = np.square(np.linalg.norm(self.gradient))

                self.numer_learning_rate = np.multiply(self.gradient ,self.gradient_norm_squared)

                self.denom_learning_rate = (self.gradient_transpose.dot(self.hessian_matrix)).dot(self.gradient)

                self.w_hat = (prev_w_hat - np.divide(self.numer_learning_rate, self.denom_learning_rate))

                self.yhat_train = self.x_train.dot (self.w_hat)
                self.yhat_test = self.x_test.dot (self.w_hat)

                """Calculating the error for the parameter values at iteration  """

                self.current_error_test = np.linalg.norm(self.yhat_test - self.y_test)**2
                self.current_error_train = np.linalg.norm(self.yhat_train - self.y_train)**2

                self.current_error_test_diff = (self.y_test - self.yhat_test)
                self.current_error_train_diff = (self.y_train - self.yhat_train)
                if (i == 0):
                    np.put(self.error_train_diff, i, self.current_error_train_diff)
                    np.put (self.error_test_diff, i, self.current_error_test_diff)
                    np.put(self.error_train, i, self.current_error_train)
                    np.put (self.error_test, i, self.current_error_test)
                    np.put(self.w_vector,i,np.linalg.norm(self.w_hat))
                    np.put(self.cost_function_gradient_vector,i,self.gradient[0])


                elif (i > 0):
                    self.error_train_diff = np.append(self.error_train_diff, self.current_error_train_diff)
                    self.error_test_diff = np.append (self.error_test_diff, self.current_error_test_diff)
                    self.error_train = np.append(self.error_train, self.current_error_train)
                    self.error_test = np.append (self.error_test, self.current_error_test)
                    self.w_vector = np.append (self.w_vector, np.linalg.norm(self.w_hat))
                    self.cost_function_gradient_vector = np.append (self.cost_function_gradient_vector, np.linalg.norm(self.gradient))

                    if (abs(self.w_vector[i-1] - self.w_vector[i]) <= stopping_condn or i >= loop_limit-1):
                        self.logger.info("Steepest Descent- Final Change in Error:"+str((self.error_test[i-1] - self.current_error_test)))
                        self.logger.info ("Steepest Descent- Final Change in W:" + str ((self.w_vector[i-1] - self.w_vector[i])))
                        self.logger.info("Steepest Descent - No.of iterations required to reach stopping condn:"+str(i))
                        self.logger.info("Steepest Descent - Value of error at stopping condn:" + str(self.current_error_test))
                        self.yhat_test = self.x_test.dot (self.w_hat)
                        self.yhat_train = self.x_train.dot (self.w_hat)

                        break
        except (SystemExit, KeyboardInterrupt):
            raise
        except (ArithmeticError, OverflowError,FloatingPointError,ZeroDivisionError) as mathError:
            self.logger.error('Math error - Failed to prepare the csv data', exc_info=True)
            raise

        except Exception as e:
            self.logger.error('Failed to calculate gradient descent', exc_info=True)
            raise

        return self.w_hat,self.yhat_train,self.error_train_diff,self.yhat_test,self.error_test_diff,self.y_test,self.y_train,self.gradient,self.current_error_train,self.current_error_test

# %%------SOLUTION 4 RIDGE regression
    def ridgeRegression(self,plot,kfoldcall=0,lamba=0):
       
        self.logger.debug("Start loop for Steepest descent/Newton method with stopping condn...")
        try:
            identity_matrix=np.eye(self.x_train.shape[1])
            
            if kfoldcall==0:
                
                self.logger.debug("Start loop for Ridge Regression with stopping condn...")
                lmda_values=[]
                train_kfold_ridge_mse=[]
                test_kfold_ridge_mse=[]

                self.data=pd.DataFrame(self.data)
                kfold=Kfold(self.data)
                #find MSE of different alphas
                while lamba<12:
                    self.logger.info("Lamda value:"+str(lamba))
                    lmda_values.append(lamba)
                    
                    kfold.kfold_fn(ridgeonly=1,lmda=lamba,plot=0)
                    train_kfold_ridge_mse.append(kfold.ridgeTrain)
                    test_kfold_ridge_mse.append(kfold.ridgeTest)
        #            ridge_weight.append(weight)
                    lamba=lamba+0.1
                    
                if plot==1:
                    
                    self.logger.info("Graph for Ridge Regression Lambda Value")
                    train_kfold_ridge_mse=np.array(train_kfold_ridge_mse)
                    self.kfold_train_mse=train_kfold_ridge_mse.mean(axis=1)
                    
                    test_kfold_ridge_mse=np.array(test_kfold_ridge_mse)
                    self.kfold_test_mse=test_kfold_ridge_mse.mean(axis=1)
                    
                    fig, ax = plt.subplots()
                    ax.plot([round(elem,2) for elem in lmda_values],self.kfold_test_mse)
                    xmin = [round(elem,2) for elem in lmda_values][np.argmin(self.kfold_test_mse)]
                    ymin = self.kfold_test_mse.min()
                    text= "Alpha={:.3f}, TestMSE={:.3f}".format(xmin, ymin)
                    if not ax:
                        ax=plt.gca()
                    bbox_props = dict(boxstyle="square,pad=0.3", fc="w", ec="k", lw=0.72)
                    arrowprops=dict(arrowstyle="->",connectionstyle="angle,angleA=0,angleB=60")
                    kw = dict(xycoords='data',textcoords="axes fraction",
                              arrowprops=arrowprops, bbox=bbox_props, ha="right", va="top")
                    ax.annotate(text,size=15, xy=(xmin, ymin), xytext=(0.90,0.94),**kw)
                    ax.set_ylim(1.1,1.3)
                    
                    ax.set_xlabel("Alpha Values")
                    ax.set_ylabel("Test Data MSE")
                    ax.set_title("Ridge Regression Lambda Selection: Test MSE vs Alpha")
                    ax.grid(True)            
                self.lmda=4.5    
                return(self.kfold_train_mse,self.kfold_test_mse,self.lmda)   
          
            else:
                self.logger.info("Running Ridge Regression with Lambda:"+str(lamba))
                lmda=math.exp(lamba)
                self.w_hat=(np.linalg.inv(self.x_train_transpose.dot(self.x_train)+lmda*identity_matrix)).dot(self.x_train_transpose).dot(self.y_train)
                
                #predicting Train and test using weights
                self.yhat_train=np.dot(self.x_train,self.w_hat)
                self.yhat_test=np.dot(self.x_test,self.w_hat)
            
                #MSE for Training Data
                self.current_error_train=np.linalg.norm(self.y_train-self.yhat_train)**2
               
                #MSE for Testing Data
                self.current_error_test=np.linalg.norm(self.y_test-self.yhat_test)**2
                
                self.error_train_diff = self.y_train - self.yhat_train
                self.error_test_diff = self.y_test - self.yhat_test
                
        except (SystemExit, KeyboardInterrupt):
            raise
        except (ArithmeticError, OverflowError,FloatingPointError,ZeroDivisionError) as mathError:
            self.logger.error('Math error - Failed to prepare the csv data', exc_info=True)
            raise

        except Exception as e:
            self.logger.error('Failed to calculate ridge regression', exc_info=True)
            raise
        
        return self.w_hat,self.y_test,self.y_train,self.yhat_train,self.error_train_diff,self.yhat_test,self.error_test_diff,self.current_error_train,self.current_error_test
# %%------SOLUTION 5 - PCR
    def pcr(self, percent=0.99):
        try:
            R_Cov_X_train = np.cov (self.x_train_transpose)
            eig_values, eig_vectors = np.linalg.eig (R_Cov_X_train)
            eig_values = np.real (eig_values)
            eig_vectors = np.real (eig_vectors)

            P_param_eig_va_sum = np.absolute (eig_values).sum ( )
            ordered_eigen_values = np.flip (np.argsort (eig_values), 0)
            sum_eig_values = 0
            L_Important_features_count = 0
            keep_feature = []
            while sum_eig_values < percent * P_param_eig_va_sum and L_Important_features_count < len (
                    ordered_eigen_values):
                sum_eig_values += abs (eig_values[ordered_eigen_values[L_Important_features_count]])
                keep_feature.append (ordered_eigen_values[L_Important_features_count])
                L_Important_features_count += 1
            print ("L_Important_features_count:", L_Important_features_count)

            features_to_delete = np.setdiff1d (range (len (eig_values)), keep_feature)
            eig_values_L = np.delete (eig_values, features_to_delete)
            eig_vectors_L = np.delete (eig_vectors, features_to_delete, 1)

            reduced_eigen_values = eig_values_L
            reduced_eigen_vector = eig_vectors_L

            self.logger.info ("Selecting feautures as principal components")
            self.w_hat = (1 / (len (self.x_train))) * (
                np.dot (reduced_eigen_vector, np.linalg.inv (np.diag (reduced_eigen_values))).dot (
                    (reduced_eigen_vector.T)).dot (self.x_train_transpose).dot (self.y_train))
            self.yhat_train = self.x_train.dot (self.w_hat)
            self.yhat_test = self.x_test.dot (self.w_hat)
            self.trainpcr_mse = np.linalg.norm (self.y_train - self.yhat_train) ** 2
            self.testpcr_mse = np.linalg.norm (self.y_test - self.yhat_test) ** 2
            self.error_train_diff = self.y_train - self.yhat_train
            self.error_test_diff = self.y_test - self.yhat_test
            return self.w_hat, self.y_test, self.y_train, self.yhat_train, self.error_train_diff, self.yhat_test, self.error_test_diff, self.trainpcr_mse, self.testpcr_mse

        except (SystemExit, KeyboardInterrupt):
            raise
        except (ArithmeticError, OverflowError, FloatingPointError, ZeroDivisionError) as mathError:
            self.logger.error ('Math error - Failed to prepare the csv data', exc_info=True)
            raise

        except Exception as e:
            self.logger.error ('Failed to run PCR', exc_info=True)
            raise
        

#%%
class Kfold(Exception):
    def __init__(self,data):
        
        self.data = data
        self.trainMSE=[[],[],[],[],[]]
        self.testMSE=[[],[],[],[],[]]
        self.ridgeTrain=[]
        self.ridgeTest=[]
        
        self.test_patients=[[],[],[],[],[]]
        self.test_patients[0].extend([33,42])
        self.test_patients[1].extend([25,32])
        self.test_patients[2].extend([17,24])
        self.test_patients[3].extend([9,16])
        self.test_patients[4].extend([1,8])
        
        
        
        self.logger = logging.getLogger(__name__)
        path = ('log_config.json')
        if os.path.exists(path):
            with open(path, 'rt') as f:
                config = json.load(f)
            logging.config.dictConfig(config)

        else:
            logging.config.dictConfig({
                'version': 1,
                'disable_existing_loggers': False,  
                'formatters': {
                    'standard': {
                        'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
                    },
                },
                'handlers': {
                    'default': {
                        'level': 'INFO',
                        'class': 'logging.StreamHandler',
                    },
                },
                'loggers': {
                    '': {
                        'handlers': ['default'],
                        'level': 'INFO',
                        'propagate': True
                    }
                }
            })
    
    def kfold_fn(self,ridgeonly,lmda,plot):
        try:
            self.logger.debug("Start loop for kfold with stopping condn...")
            
            for i in range(0,5):
                #splitting test and train data
                kfold_train_data=self.data.drop(self.data[self.data["subject#"].between(self.test_patients[i][0],self.test_patients[i][1],inclusive=True)==1].index)
                kfold_test_data=self.data[self.data["subject#"].between(self.test_patients[i][0],self.test_patients[i][1],inclusive=True)]
            
                kfold_train_data=kfold_train_data.reset_index(drop=True)
                kfold_test_data=kfold_test_data.reset_index(drop=True)
                x_train_kfold=kfold_train_data.iloc[:,:]
                x_test_kfold=kfold_test_data.iloc[:,:]
                 
                #normalizing the data with zero mean and unit variance
                mean=x_train_kfold.mean()
                stdDev=x_train_kfold.std()
                kfold_xtrain=(x_train_kfold-mean)/stdDev
                kfold_xtest=(x_test_kfold-mean)/stdDev
                 
                #Deciding the output column for training and testing data
                y_train_kfold=kfold_xtrain["total_UPDRS"]
                y_test_kfold=kfold_xtest["total_UPDRS"]
                 
                #dropping output column from input data
                kfold_xtrain=kfold_xtrain.drop(['subject#','age','sex','test_time','total_UPDRS'],axis=1)
                kfold_xtest=kfold_xtest.drop(['subject#','age','sex','test_time','total_UPDRS'],axis=1)
                
                if ridgeonly==1:
                    
                    rr=RegressionTechniques(kfold_xtrain,kfold_xtest,y_train_kfold,y_test_kfold,self.data)
                    rr.ridgeRegression(plot=0,kfoldcall=1,lamba=lmda)
                    self.ridgeTrain.append(rr.current_error_train/kfold_xtrain.shape[0])
                    self.ridgeTest.append(rr.current_error_test/kfold_xtest.shape[0])
                
                else:
                    
                    mse = RegressionTechniques(kfold_xtrain,kfold_xtest,y_train_kfold,y_test_kfold,self.data)

                    gd = RegressionTechniques(kfold_xtrain,kfold_xtest,y_train_kfold,y_test_kfold,self.data)
        
                    sd = RegressionTechniques(kfold_xtrain,kfold_xtest,y_train_kfold,y_test_kfold,self.data)
        
                    rr =  RegressionTechniques(kfold_xtrain,kfold_xtest,y_train_kfold,y_test_kfold,self.data)
                    
                    pcr = RegressionTechniques(kfold_xtrain,kfold_xtest,y_train_kfold,y_test_kfold,self.data)

                    self.algorithm_labels =['mse','gd','sd','rr','pcr']
                    mse.calculate_MSE(mean_axis=0)
                    self.trainMSE[i].append(mse.error_train_MSE/kfold_xtrain.shape[0])
                    self.testMSE[i].append(mse.error_test_mse/kfold_xtest.shape[0])
#                    
                    gd.gradientDescent(stopping_condn = 10**-5,loop_limit=2*10**4,gamma=10 ** (-4))
                    self.trainMSE[i].append(gd.current_error_train/kfold_xtrain.shape[0])
                    self.testMSE[i].append(gd.current_error_test/kfold_xtest.shape[0])
                    
                    sd.steepestDescent_Hessian (stopping_condn=10**-5, loop_limit=2*10**4)
                    self.trainMSE[i].append(sd.current_error_train/kfold_xtrain.shape[0])
                    self.testMSE[i].append(sd.current_error_test/kfold_xtest.shape[0])
                    
                    rr.ridgeRegression(plot=plot,kfoldcall=1,lamba=lmda)
                    self.trainMSE[i].append(rr.current_error_train/kfold_xtrain.shape[0])
                    self.testMSE[i].append(rr.current_error_test/kfold_xtest.shape[0])
                    
                    pcr.pcr(percent=0.99)
                    self.trainMSE[i].append(pcr.trainpcr_mse/kfold_xtrain.shape[0])
                    self.testMSE[i].append(pcr.testpcr_mse/kfold_xtest.shape[0])
            
        
        except (SystemExit, KeyboardInterrupt):
            raise
        except (ArithmeticError, OverflowError,FloatingPointError,ZeroDivisionError) as mathError:
            self.logger.error('Math error - Failed to prepare the csv data', exc_info=True)
            raise

        except Exception as e:
            self.logger.error('Failed to calculate gradient descent', exc_info=True)
            raise
        
        return(self.trainMSE,self.testMSE,self.ridgeTrain,self.ridgeTest)
        